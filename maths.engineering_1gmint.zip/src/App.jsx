import React, { useState, useEffect } from 'react';
    import Navbar from './components/Navbar';
    import Sidebar from './components/Sidebar';
    import VideoList from './components/VideoList';
    import VideoPlayer from './components/VideoPlayer';
    import './App.css';
    import { getAllVideos, getVideoById } from './database';

    const App = () => {
      const [selectedVideo, setSelectedVideo] = useState(null);
      const [videos, setVideos] = useState([]);

      useEffect(() => {
        const fetchVideos = async () => {
          const videoData = await getAllVideos();
          setVideos(videoData);
          if (videoData.length > 0) {
            setSelectedVideo(videoData[0]); // Select the first video by default
          }
        };

        fetchVideos();
      }, []);

      const handleVideoSelect = async (video) => {
          setSelectedVideo(video);
      };

      return (
        <div className="app">
          <Navbar />
          <div className="main-content">
            <Sidebar />
            <div className="video-section">
              {selectedVideo ? (
                <VideoPlayer video={selectedVideo} />
              ) : (
                <VideoList videos={videos} onVideoSelect={handleVideoSelect} />
              )}
            </div>
          </div>
        </div>
      );
    };

    export default App;
