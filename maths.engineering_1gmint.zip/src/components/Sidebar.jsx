import React from 'react';
    import './Sidebar.css'

    const Sidebar = () => {
      return (
        <div className="sidebar">
          <ul>
            <li>Home</li>
            <li>Trending</li>
            <li>Subscriptions</li>
            <li>Library</li>
            <li>History</li>
          </ul>
        </div>
      );
    };

    export default Sidebar;
