import React from 'react';
    import './VideoPlayer.css'

    const VideoPlayer = ({ video }) => {
      return (
        <div className="video-player">
          <iframe
            title={video.title}
            src={`https://www.youtube.com/embed/${video.id}`} // In a real app, you'd have actual video IDs.
            allowFullScreen
          ></iframe>
          <h2>{video.title}</h2>
          <p>{video.channel}</p>
          <p>{video.views} views</p>
        </div>
      );
    };

    export default VideoPlayer;
