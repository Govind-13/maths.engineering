import React from 'react';
    import './Navbar.css';

    const Navbar = () => {
      return (
        <div className="navbar">
          <div className="logo">YouTube Clone</div>
          <div className="search-bar">
            <input type="text" placeholder="Search" />
            <button>Search</button>
          </div>
          <div className="user-icons">
            {/* Add user icons here */}
          </div>
        </div>
      );
    };

    export default Navbar;
