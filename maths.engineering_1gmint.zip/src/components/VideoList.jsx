import React from 'react';
    import './VideoList.css';

    const VideoList = ({ videos, onVideoSelect }) => {

      return (
        <div className="video-list">
          {videos.map((video) => (
            <div key={video.id} className="video-item" onClick={() => onVideoSelect(video)}>
              <img src={video.thumbnailUrl} alt={video.title} />
              <div className="video-info">
                <h3>{video.title}</h3>
                <p>{video.channel}</p>
                <p>{video.views} views</p>
              </div>
            </div>
          ))}
        </div>
      );
    };

    export default VideoList;
