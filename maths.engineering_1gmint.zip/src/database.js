import initSqlJs from 'sql.js';

    let dbInstance;

    async function getDbInstance() {
        if (!dbInstance) {
            const SQL = await initSqlJs({
                locateFile: file => `https://sql.js.org/dist/${file}`
            });
            dbInstance = new SQL.Database();

            // Create table and seed data
            dbInstance.exec(`
                CREATE TABLE videos (
                    id INTEGER PRIMARY KEY,
                    title TEXT,
                    thumbnailUrl TEXT,
                    channel TEXT,
                    views TEXT
                );
            `);

            const initialVideos = [
                { id: 1, title: 'Video 1', thumbnailUrl: 'https://source.unsplash.com/featured/300x170?nature', channel: 'Channel A', views: '1M' },
                { id: 2, title: 'Video 2', thumbnailUrl: 'https://source.unsplash.com/featured/300x170?travel', channel: 'Channel B', views: '2M' },
                { id: 3, title: 'Video 3', thumbnailUrl: 'https://source.unsplash.com/featured/300x170?technology', channel: 'Channel C', views: '3M' },
                { id: 4, title: 'Video 4', thumbnailUrl: 'https://source.unsplash.com/featured/300x170?food', channel: 'Channel A', views: '4M' },
                { id: 5, title: 'Video 5', thumbnailUrl: 'https://source.unsplash.com/featured/300x170?music', channel: 'Channel B', views: '5M' },
                { id: 6, title: 'Video 6', thumbnailUrl: 'https://source.unsplash.com/featured/300x170?art', channel: 'Channel C', views: '6M' },
            ];

            const stmt = dbInstance.prepare('INSERT INTO videos (id, title, thumbnailUrl, channel, views) VALUES (?, ?, ?, ?, ?)');
            for (const video of initialVideos) {
                stmt.bind([video.id, video.title, video.thumbnailUrl, video.channel, video.views]);
                stmt.step(); // Execute the statement
            }
            stmt.free();
        }
        return dbInstance;
    }

    export async function getAllVideos() {
      const db = await getDbInstance();
      const result = [];
      const stmt = db.prepare('SELECT * FROM videos');

      while (stmt.step()) {
        result.push(stmt.getAsObject());
      }
      stmt.free();
      return result;
    }

    export async function getVideoById(id) {
        const db = await getDbInstance();
        const stmt = db.prepare('SELECT * FROM videos WHERE id = ?');
        stmt.bind([id]);

        let result = null;
        if (stmt.step()) { // Check if there's a result
          result = stmt.getAsObject();
        }

        stmt.free();
        return result; // Return null if no video found, or the video object
    }
